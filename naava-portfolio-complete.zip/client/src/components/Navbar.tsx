import { useState } from "react";
import { Menu, X } from "lucide-react";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur border-b border-[#a8e6d9]/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-[#ffc9a3]" style={{ fontFamily: "var(--font-display)" }}>
              NAAVA
            </span>
            <span className="text-xs font-mono text-[#8b8b8b]">// Artist Manager</span>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#about" className="text-sm font-semibold text-[#2d2d2d] hover:text-[#ffc9a3] transition">
              About
            </a>
            <a href="#experience" className="text-sm font-semibold text-[#2d2d2d] hover:text-[#ffc9a3] transition">
              Experience
            </a>
            <a href="#projects" className="text-sm font-semibold text-[#2d2d2d] hover:text-[#ffc9a3] transition">
              Projects
            </a>
            <a href="#contact" className="text-sm font-semibold text-[#2d2d2d] hover:text-[#ffc9a3] transition">
              Contact
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 hover:bg-[#a8e6d9]/10 rounded"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden pb-4 space-y-2">
            <a href="#about" className="block px-4 py-2 text-sm font-semibold text-[#2d2d2d] hover:bg-[#a8e6d9]/10 rounded">
              About
            </a>
            <a href="#experience" className="block px-4 py-2 text-sm font-semibold text-[#2d2d2d] hover:bg-[#a8e6d9]/10 rounded">
              Experience
            </a>
            <a href="#projects" className="block px-4 py-2 text-sm font-semibold text-[#2d2d2d] hover:bg-[#a8e6d9]/10 rounded">
              Projects
            </a>
            <a href="#contact" className="block px-4 py-2 text-sm font-semibold text-[#2d2d2d] hover:bg-[#a8e6d9]/10 rounded">
              Contact
            </a>
          </div>
        )}
      </div>
    </nav>
  );
}
