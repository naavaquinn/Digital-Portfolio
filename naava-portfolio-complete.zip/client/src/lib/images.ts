/*
 * Image URLs — CDN references for portfolio assets
 */

export const IMAGES = {
  hero: "https://images.unsplash.com/photo-1611339555312-e607c04352fa?w=1200&h=600&fit=crop",
  aboutMap: "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?w=600&h=400&fit=crop",
  metricsBackground: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1200&h=600&fit=crop",
  socialCollage: "https://images.unsplash.com/photo-1611532736579-6b16e2b50449?w=1200&h=600&fit=crop",
  toolsWorkspace: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=600&h=400&fit=crop",
  brandDeals: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=1200&h=600&fit=crop",
  revenueChart: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop",
};
