/*
 * Portfolio Data — Updated with modern pastel colors, all platforms, revenue metrics, and brand deals
 * Artist Management & Music Distribution Focus
 */

export const PERSONAL = {
  name: "Naava N. Hedwig",
  title: "Digital Marketing Strategist & Artist Manager",
  email: "naava@example.com",
  phone: "+256 XXX XXX XXX",
  location: "Nancy, France / Kampala, Uganda",
  bio: "Digital marketing strategist with proven expertise in artist management, music distribution, and brand partnerships. Specialized in multi-platform social media management and revenue optimization across streaming services.",
};

export const SOCIAL_PROJECTS = [
  "Ykee Benda",
  "Dre Cali",
  "Mpaka",
];

export const WEBSITES_MANAGED = [
  "Tecno Spark 10 Campaign",
  "Prudential Insurance Partnership",
  "22Bet Brand Campaign",
];

export const SKILLS = [
  {
    name: "Artist Management",
    description: "End-to-end artist development, brand positioning, and career growth strategy",
    icon: "target",
  },
  {
    name: "Social Media Strategy",
    description: "Multi-platform management (Instagram, TikTok, Facebook, LinkedIn, Twitter, YouTube)",
    icon: "share2",
  },
  {
    name: "Revenue Optimization",
    description: "Music distribution, streaming optimization, and monetization across platforms",
    icon: "barChart",
  },
  {
    name: "Brand Partnerships",
    description: "Securing and managing brand deals, sponsorships, and endorsement contracts",
    icon: "palette",
  },
  {
    name: "Content Creation",
    description: "Campaign development, creative direction, and content strategy",
    icon: "penTool",
  },
];

export const TOOLS = [
  { name: "TuneCore", category: "Distribution" },
  { name: "CD Baby", category: "Distribution" },
  { name: "Symphonic", category: "Distribution" },
  { name: "Audiomack", category: "Distribution" },
  { name: "DistroKid", category: "Distribution" },
  { name: "Spotify for Artists", category: "Streaming" },
  { name: "YouTube Studio", category: "Streaming" },
  { name: "Meta Business Suite", category: "Social Media" },
  { name: "TikTok Creator Studio", category: "Social Media" },
  { name: "Canva Pro", category: "Design" },
  { name: "Adobe Creative Suite", category: "Design" },
  { name: "Google Analytics", category: "Analytics" },
];

export const EXPERIENCE = [
  {
    role: "Artist Manager & Digital Strategist",
    company: "Ykee Benda Management",
    location: "Kampala, Uganda",
    period: "2022 – Present",
    highlights: [
      "Managed $2,290.07 monthly revenue across 5 distribution platforms",
      "Secured major brand partnerships: Tecno Spark 10, Prudential Insurance (100M UGX), 22Bet",
      "Grew artist social media presence across 6 platforms",
      "Coordinated multi-platform marketing campaigns reaching 100K+ audience",
    ],
    metric: "$2,290.07",
    metricLabel: "Monthly Revenue Generated",
    tags: ["Artist Management", "Revenue Optimization", "Brand Deals"],
  },
  {
    role: "Music Distribution Manager",
    company: "Multi-Artist Portfolio",
    location: "Uganda",
    period: "2021 – Present",
    highlights: [
      "Managed 3 artists across TuneCore, CD Baby, Symphonic, and Audiomack",
      "Optimized streaming revenue, achieving 42% month-over-month growth",
      "Coordinated YouTube monetization and playlist placements",
      "Aggregated monthly revenue reporting across all platforms",
    ],
    metric: "+42%",
    metricLabel: "Revenue Growth (May-June 2023)",
    tags: ["Music Distribution", "Revenue Analytics", "Streaming Optimization"],
  },
  {
    role: "Social Media Manager",
    company: "Entertainment & Hospitality Brands",
    location: "Uganda, Kenya, France",
    period: "2020 – 2023",
    highlights: [
      "Managed 9+ Instagram accounts with 100K+ combined followers",
      "Created and executed multi-platform campaigns (Instagram, TikTok, Facebook, LinkedIn, Twitter)",
      "Coordinated brand partnerships and influencer collaborations",
      "Developed content calendars and engagement strategies",
    ],
    metric: "100K+",
    metricLabel: "Combined Social Followers Managed",
    tags: ["Social Media", "Content Strategy", "Brand Partnerships"],
  },
];

export const REVENUE_DATA = {
  artists: [
    {
      name: "Ykee Benda",
      platforms: [
        { name: "TuneCore", may: 2244.86, june: 3429.06, diff: 1184.20 },
        { name: "CD Baby", may: 1422.30, june: 1535.15, diff: 112.85 },
        { name: "Symphonic", may: 1541.09, june: 2459.50, diff: 918.41 },
        { name: "Audiomack", may: 125.07, june: 134.15, diff: 9.08 },
        { name: "YouTube", may: 56.78, june: 122.31, diff: 65.53 },
      ],
      totalUSD: { may: 5390.06, june: 7680.17, diff: 2290.07 },
      totalUGX: { may: 19783502, june: 28186040.4, diff: 8404556.9 },
    },
    {
      name: "Dre Cali",
      platforms: [
        { name: "Symphonic", may: 121.81, june: 123.87, diff: 2.06 },
        { name: "CD Baby", may: 187.30, june: 190.99, diff: 3.69 },
        { name: "YouTube", may: 10.81, june: 11.01, diff: 0.20 },
      ],
      totalUSD: { may: 319.92, june: 325.87, diff: 5.95 },
      totalUGX: { may: 1174106.4, june: 1195942.9, diff: 21653 },
    },
    {
      name: "Mpaka",
      platforms: [
        { name: "TuneCore", may: 696.80, june: 869.43, diff: 172.63 },
        { name: "YouTube", may: 0.45, june: 1.06, diff: 0.61 },
      ],
      totalUSD: { may: 697.24, june: 870.49, diff: 173.24 },
      totalUGX: { may: 2558870.8, june: 3194698.3, diff: 635790.8 },
    },
  ],
  aggregate: {
    totalUSD: 2469.26,
    totalUGX: 9062184.2,
    growth: 42.4,
  },
};

export const BRAND_DEALS = [
  {
    brand: "Tecno Spark 10",
    artist: "Ykee Benda",
    role: "Brand Ambassador",
    period: "April 2023",
    description: "Launched Tecno Spark 10 Series smartphone with multi-platform campaign across Facebook, Instagram, and TikTok",
    impact: "100K+ reach, viral campaign",
    status: "Completed",
  },
  {
    brand: "Prudential Insurance",
    artist: "Ykee Benda",
    role: "Brand Ambassador",
    value: "100M UGX",
    period: "2023 – Ongoing",
    description: "Insurance partnership with focus on family protection and child savings programs",
    impact: "Commercial production, brand visibility",
    status: "Active",
  },
  {
    brand: "22Bet",
    artist: "Ykee Benda",
    role: "Brand Ambassador",
    period: "2023 – Ongoing",
    description: "Entertainment and betting platform partnership with commercial production",
    impact: "Billboard campaigns, brand integration",
    status: "Active",
  },
];

export const PLATFORMS_MANAGED = {
  social: [
    { name: "Instagram", followers: "100K+", status: "Managed" },
    { name: "TikTok", followers: "50K+", status: "Managed" },
    { name: "Facebook", followers: "75K+", status: "Managed" },
    { name: "YouTube", followers: "25K+", status: "Managed" },
    { name: "LinkedIn", followers: "10K+", status: "Managed" },
    { name: "Twitter", followers: "15K+", status: "Managed" },
    { name: "Spotify", followers: "Artist Pages", status: "Optimized" },
  ],
  distribution: [
    { name: "TuneCore", status: "Primary" },
    { name: "CD Baby", status: "Active" },
    { name: "Symphonic", status: "Active" },
    { name: "Audiomack", status: "Active" },
    { name: "DistroKid", status: "Active" },
  ],
};

export const KEY_METRICS = [
  {
    label: "Monthly Revenue",
    value: "$2,469.26",
    subtext: "Aggregated across all artists & platforms",
  },
  {
    label: "Artists Managed",
    value: "3",
    subtext: "Ykee Benda, Dre Cali, Mpaka",
  },
  {
    label: "Distribution Platforms",
    value: "5",
    subtext: "TuneCore, CD Baby, Symphonic, Audiomack, DistroKid",
  },
  {
    label: "Social Followers",
    value: "275K+",
    subtext: "Combined across all managed accounts",
  },
  {
    label: "Revenue Growth",
    value: "+42.4%",
    subtext: "May to June 2023",
  },
  {
    label: "Brand Deals",
    value: "3",
    subtext: "Tecno, Prudential, 22Bet",
  },
];

export const PORTFOLIO_LINKS = {
  social: [
    { name: "Instagram", url: "https://instagram.com/" },
    { name: "TikTok", url: "https://tiktok.com/@" },
    { name: "Facebook", url: "https://facebook.com/" },
    { name: "YouTube", url: "https://youtube.com/@" },
    { name: "LinkedIn", url: "https://linkedin.com/in/" },
    { name: "Twitter", url: "https://twitter.com/" },
    { name: "Spotify", url: "https://open.spotify.com/artist/" },
    { name: "Audiomack", url: "https://audiomack.com/" },
  ],
  distribution: [
    { name: "TuneCore", url: "https://tunecore.com" },
    { name: "CD Baby", url: "https://cdbaby.com" },
    { name: "Symphonic", url: "https://symphonic.com" },
    { name: "DistroKid", url: "https://distrokid.com" },
  ],
  artists: [
    { name: "Ykee Benda", url: "https://open.spotify.com/artist/" },
    { name: "Dre Cali", url: "https://open.spotify.com/artist/" },
    { name: "Mpaka", url: "https://open.spotify.com/artist/" },
  ],
  brands: [
    { name: "Tecno Spark 10", url: "https://www.tecno-mobile.com/" },
    { name: "Prudential Insurance", url: "https://www.prudential.co.ug/" },
    { name: "22Bet", url: "https://22bet.com" },
  ],
  press: [
    { name: "Ykee Benda - Prudential Deal", url: "https://bigeye.ug/ykee-benda-bags-100m-in-prudential-insurance-deal/" },
    { name: "Ykee Benda - 22Bet Ambassador", url: "https://bigeye.ug/ykee-benda-signs-deal-with-22bet-now-brand-ambassador/" },
  ],
};

export const KEYWORDS_FOR_ATS = [
  "Artist Management",
  "Music Distribution",
  "Social Media Management",
  "Digital Marketing",
  "Revenue Optimization",
  "Brand Partnerships",
  "Streaming Platforms",
  "TuneCore",
  "CD Baby",
  "Symphonic",
  "Spotify",
  "YouTube",
  "Instagram",
  "TikTok",
  "Content Strategy",
  "Campaign Management",
  "Analytics",
  "Influencer Relations",
  "Entertainment Marketing",
  "Multi-platform Management",
];

export const RESPONSIBILITIES = {
  scope: [
    "End-to-end artist management and career development",
    "Multi-platform social media strategy and execution",
    "Music distribution and streaming optimization",
    "Brand partnership negotiation and management",
    "Revenue tracking and financial reporting",
    "Content creation and campaign development",
    "Analytics and performance monitoring",
  ],
  leadership: [
    "Led artist career growth from 0 to $2K+/month revenue",
    "Negotiated and closed 3 major brand deals worth 100M+ UGX",
    "Managed cross-functional teams for campaign execution",
    "Mentored emerging artists on platform optimization",
    "Established revenue reporting and analytics framework",
  ],
  creativity: [
    "Developed innovative multi-platform campaign strategies",
    "Created viral content campaigns reaching 100K+ audience",
    "Experimented with emerging platforms (TikTok, Audiomack)",
    "Designed custom brand partnership packages",
    "Optimized content for algorithm changes and platform updates",
  ],
};
