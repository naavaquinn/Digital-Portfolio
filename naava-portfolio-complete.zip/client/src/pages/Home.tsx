import Navbar from "@/components/Navbar";

export default function Home() {
  return (
    <div className="min-h-screen bg-[#fef9f3]">
      <Navbar />
      
      {/* Hero Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-[#fef9f3] to-[#ffc9a3]/10">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-[#2d2d2d] mb-4" style={{ fontFamily: "var(--font-display)" }}>
            Artist Manager & Digital Strategist
          </h1>
          <p className="text-xl text-[#8b8b8b] mb-8">
            Managing artists, optimizing revenue, and securing brand partnerships across music distribution and social media platforms.
          </p>
          <a href="#contact" className="inline-block px-8 py-3 bg-[#ffc9a3] text-white font-bold rounded-lg hover:bg-[#ff9d6f] transition">
            Get in Touch
          </a>
        </div>
      </section>

      {/* Key Metrics */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-[#2d2d2d] mb-12 text-center" style={{ fontFamily: "var(--font-display)" }}>
            Proof of Impact
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 bg-gradient-to-br from-[#a8e6d9]/20 to-transparent rounded-lg border border-[#a8e6d9]/30">
              <div className="text-3xl font-bold text-[#a8e6d9] mb-2">$2,469.26</div>
              <p className="text-sm text-[#8b8b8b]">Monthly Revenue Aggregated</p>
            </div>
            <div className="p-6 bg-gradient-to-br from-[#ffc9a3]/20 to-transparent rounded-lg border border-[#ffc9a3]/30">
              <div className="text-3xl font-bold text-[#ffc9a3] mb-2">+42.4%</div>
              <p className="text-sm text-[#8b8b8b]">Revenue Growth (May-June)</p>
            </div>
            <div className="p-6 bg-gradient-to-br from-[#d4b5f0]/20 to-transparent rounded-lg border border-[#d4b5f0]/30">
              <div className="text-3xl font-bold text-[#d4b5f0] mb-2">3</div>
              <p className="text-sm text-[#8b8b8b]">Major Brand Deals</p>
            </div>
          </div>
        </div>
      </section>

      {/* Platforms Managed */}
      <section className="py-16 px-4 bg-[#fef9f3]">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-[#2d2d2d] mb-12 text-center" style={{ fontFamily: "var(--font-display)" }}>
            Platforms & Tools
          </h2>
          
          <div className="mb-12">
            <h3 className="text-xl font-bold text-[#2d2d2d] mb-6">Social Media</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {["Instagram", "TikTok", "Facebook", "YouTube", "LinkedIn", "Twitter", "Spotify", "Audiomack"].map((platform) => (
                <div key={platform} className="p-4 bg-white rounded-lg border border-[#a8e6d9]/30 text-center hover:border-[#ffc9a3]/50 transition">
                  <p className="font-semibold text-[#2d2d2d]">{platform}</p>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold text-[#2d2d2d] mb-6">Music Distribution</h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {["TuneCore", "CD Baby", "Symphonic", "Audiomack", "DistroKid"].map((platform) => (
                <div key={platform} className="p-4 bg-white rounded-lg border border-[#ffc9a3]/30 text-center hover:border-[#a8e6d9]/50 transition">
                  <p className="font-semibold text-[#2d2d2d]">{platform}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Brand Deals */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-[#2d2d2d] mb-12 text-center" style={{ fontFamily: "var(--font-display)" }}>
            Brand Partnerships
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 bg-gradient-to-br from-[#a8e6d9]/10 to-transparent rounded-lg border border-[#a8e6d9]/30">
              <h3 className="text-xl font-bold text-[#2d2d2d] mb-2">Tecno Spark 10</h3>
              <p className="text-sm text-[#8b8b8b] mb-3">Brand Ambassador - Ykee Benda</p>
              <p className="text-xs text-[#8b8b8b]">Multi-platform campaign reaching 100K+ audience</p>
            </div>
            <div className="p-6 bg-gradient-to-br from-[#ffc9a3]/10 to-transparent rounded-lg border border-[#ffc9a3]/30">
              <h3 className="text-xl font-bold text-[#2d2d2d] mb-2">Prudential Insurance</h3>
              <p className="text-sm text-[#8b8b8b] mb-3">Brand Ambassador - Ykee Benda</p>
              <p className="text-xs text-[#8b8b8b]">100M UGX deal with commercial production</p>
            </div>
            <div className="p-6 bg-gradient-to-br from-[#d4b5f0]/10 to-transparent rounded-lg border border-[#d4b5f0]/30">
              <h3 className="text-xl font-bold text-[#2d2d2d] mb-2">22Bet</h3>
              <p className="text-sm text-[#8b8b8b] mb-3">Brand Ambassador - Ykee Benda</p>
              <p className="text-xs text-[#8b8b8b]">Billboard campaigns & brand integration</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 px-4 bg-gradient-to-br from-[#ffc9a3]/20 to-[#a8e6d9]/20">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-[#2d2d2d] mb-8" style={{ fontFamily: "var(--font-display)" }}>
            Let's Connect
          </h2>
          <p className="text-lg text-[#8b8b8b] mb-8">
            Ready to discuss artist management, music distribution, or brand partnerships?
          </p>
          <a href="mailto:naava@example.com" className="inline-block px-8 py-3 bg-[#ffc9a3] text-white font-bold rounded-lg hover:bg-[#ff9d6f] transition">
            Send Me an Email
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 bg-[#2d2d2d] text-white text-center">
        <p className="text-sm">© 2024 Naava N. Hedwig. All rights reserved.</p>
      </footer>
    </div>
  );
}
